/*
Package microbit contains the Gobot drivers for the Microbit.

For more information refer to the microbit README:
https://github.com/hybridgroup/gobot/blob/master/platforms/microbit/README.md
*/
package microbit // import "gobot.io/x/gobot/platforms/microbit"
