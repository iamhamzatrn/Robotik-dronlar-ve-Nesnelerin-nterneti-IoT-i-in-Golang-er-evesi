/*
Package raspi contains the Gobot adaptor for the Raspberry Pi.

For further information refer to raspi README:
https://github.com/hybridgroup/gobot/blob/master/platforms/raspi/README.md
*/
package raspi // import "gobot.io/x/gobot/platforms/raspi"
