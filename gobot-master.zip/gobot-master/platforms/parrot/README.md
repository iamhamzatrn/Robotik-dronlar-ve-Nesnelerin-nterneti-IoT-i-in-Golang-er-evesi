# Parrot

This package contains the Gobot adaptors and drivers for the various Parrot (https://www.parrot.com) drones.

This package currently supports the following drones:
- Parrot ARDrone 2.0
- Parrot Bebop/Bebop 2
- Parrot Minidrone
