/*
Package minidrone contains the Gobot driver for the Parrot Minidrone.

For more information refer to the minidrone README:
https://github.com/hybridgroup/gobot/blob/master/platforms/parrot/minidrone/README.md
*/
package minidrone // import "gobot.io/x/gobot/platforms/parrot/minidrone"
