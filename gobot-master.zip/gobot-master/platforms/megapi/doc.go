/*
Package megapi provides the Gobot adaptor for MegaPi.

For more information refer to the README:
https://github.com/hybridgroup/gobot/blob/master/platforms/megapi/README.md
*/
package megapi // import "gobot.io/x/gobot/platforms/megapi"
