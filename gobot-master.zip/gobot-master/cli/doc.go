/*
CLI tool for generating new Gobot projects.

	NAME:
		 gobot - Command Line Utility for generating new Gobot adaptors, drivers, and platforms

	USAGE:
		 gobot [global options] command [command options] [arguments...]

*/
package main
